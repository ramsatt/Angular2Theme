import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './beta.html'
})

export class DashboardsBeta {}

