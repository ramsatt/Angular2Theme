import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './page-404.html'
})

export class PagesPage404 {}

