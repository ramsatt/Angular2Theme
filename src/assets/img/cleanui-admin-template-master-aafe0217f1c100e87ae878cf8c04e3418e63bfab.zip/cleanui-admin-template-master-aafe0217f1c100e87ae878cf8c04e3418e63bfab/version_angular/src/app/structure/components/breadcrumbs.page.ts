import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './breadcrumbs.html'
})

export class ComponentsBreadcrumbs {}

