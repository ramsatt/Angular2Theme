import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './product-edit.html'
})

export class EcommerceProductEdit {}

