import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './messaging.html'
})

export class AppsMessaging {}

