import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './basic-form-elements.html'
})

export class FormsBasicFormElements {}

