import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './invoice.html'
})

export class PagesInvoice {}

