import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './collapse.html'
})

export class ComponentsCollapse {}

