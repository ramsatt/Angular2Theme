import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './gallery.html'
})

export class AppsGallery {}

