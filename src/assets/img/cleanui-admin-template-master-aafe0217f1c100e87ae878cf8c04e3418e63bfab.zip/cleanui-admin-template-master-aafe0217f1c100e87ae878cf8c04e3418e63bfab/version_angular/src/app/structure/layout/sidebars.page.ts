import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './sidebars.html'
})

export class LayoutSidebars {}

