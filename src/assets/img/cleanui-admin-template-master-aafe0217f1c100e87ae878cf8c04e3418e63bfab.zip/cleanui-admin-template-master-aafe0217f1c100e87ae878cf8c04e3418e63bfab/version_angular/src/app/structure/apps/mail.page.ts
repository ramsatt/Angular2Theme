import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './mail.html'
})

export class AppsMail {}

