import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './checkboxes-radio.html'
})

export class FormsCheckboxesRadio {}

