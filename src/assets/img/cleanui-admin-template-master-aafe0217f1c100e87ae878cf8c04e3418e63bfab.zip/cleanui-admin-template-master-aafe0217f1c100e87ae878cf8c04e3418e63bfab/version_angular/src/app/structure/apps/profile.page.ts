import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './profile.html'
})

export class AppsProfile {}

