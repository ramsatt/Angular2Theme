import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './grid.html'
})

export class LayoutGrid {}

