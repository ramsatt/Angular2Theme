import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './alpha.html'
})

export class DashboardsAlpha {}

