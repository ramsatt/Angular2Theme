import { Component } from '@angular/core';

@Component({
  selector: 'cat-page',
  templateUrl: './pagination.html'
})

export class ComponentsPagination {}

